## ReadMe
(base) miwanoshuuhei@miwambp 05_StreamlitSqlNativeapp % snow init --template app_basic tutorial
Project identifier [my_native_app_project]: streamlit_sql_native_app
Initialized the new project in tutorial


